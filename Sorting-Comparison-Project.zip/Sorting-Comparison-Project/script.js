// Sorting Comparison Mini Project
// Both algorithms receive separate copies of the same original data.

// BUBBLE SORT
function bubbleSort(arr) {
  const n = arr.length;

  for (let i = 0; i < n - 1; i++) {
    let swapped = false;

    for (let j = 0; j < n - i - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
        swapped = true;
      }
    }

    // Stop early if this pass made no swaps.
    if (!swapped) break;
  }

  return arr;
}

// MERGE SORT
function mergeSort(arr) {
  if (arr.length <= 1) {
    return arr;
  }

  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid));
  const right = mergeSort(arr.slice(mid));

  return merge(left, right);
}

// MERGE TWO SORTED ARRAYS
function merge(left, right) {
  const result = [];
  let i = 0;
  let j = 0;

  while (i < left.length && j < right.length) {
    if (left[i] <= right[j]) {
      result.push(left[i]);
      i++;
    } else {
      result.push(right[j]);
      j++;
    }
  }

  // Append any values remaining in either half.
  return result.concat(left.slice(i), right.slice(j));
}

// Run an algorithm three times and return the median time.
// Copying the input happens OUTSIDE the timed section.
function benchmarkSort(sortFunction, originalData) {
  const times = [];
  let sortedResult = [];

  for (let run = 0; run < 3; run++) {
    const workingCopy = originalData.slice();

    const startTime = performance.now();
    sortedResult = sortFunction(workingCopy);
    const elapsedTime = performance.now() - startTime;

    times.push(elapsedTime);
  }

  times.sort((a, b) => a - b);

  return {
    result: sortedResult,
    time: times[1]
  };
}

const numbersInput = document.getElementById("numbers");
const message = document.getElementById("message");

function showMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
}

function readInput() {
  const rawInput = numbersInput.value.trim();

  // An empty input is a valid empty list (test case TC05 in the report).
  if (rawInput === "") {
    return [];
  }

  const parts = rawInput.split(",").map(value => value.trim());

  if (parts.some(value => value === "")) {
    throw new Error("Use commas between numbers. Do not leave an empty item.");
  }

  const values = parts.map(Number);

  if (values.some(value => !Number.isFinite(value))) {
    throw new Error("Please enter valid numbers only, separated by commas.");
  }

  if (values.length > 10000) {
    throw new Error("Please enter 10,000 numbers or fewer.");
  }

  return values;
}

function formatTime(milliseconds) {
  return `${milliseconds.toFixed(6)} ms`;
}

function displayBar(label, time, className, maxTime) {
  // A tiny minimum width makes a near-zero measurement visible.
  const width = maxTime === 0 ? 0 : Math.max((time / maxTime) * 100, 0.5);

  return `
    <div class="bar-row">
      <div class="bar-label">
        <span>${label}</span>
        <span>${formatTime(time)}</span>
      </div>
      <div class="bar-track">
        <div class="bar ${className}" style="width: ${width}%"></div>
      </div>
    </div>
  `;
}

function compareSorting() {
  let data;

  try {
    data = readInput();
  } catch (error) {
    showMessage(error.message, true);
    return;
  }

  // Preserve the original list and create independent copies in benchmarkSort.
  document.getElementById("original").textContent =
    data.length ? data.join(", ") : "(empty list)";
  document.getElementById("inputCount").textContent =
    `${data.length} ${data.length === 1 ? "number" : "numbers"}`;

  const bubble = benchmarkSort(bubbleSort, data);
  const merge = benchmarkSort(mergeSort, data);

  document.getElementById("bubbleResult").textContent =
    bubble.result.length ? bubble.result.join(", ") : "(empty list)";
  document.getElementById("mergeResult").textContent =
    merge.result.length ? merge.result.join(", ") : "(empty list)";

  document.getElementById("bubbleTime").textContent = formatTime(bubble.time);
  document.getElementById("mergeTime").textContent = formatTime(merge.time);

  const outputsMatch =
    JSON.stringify(bubble.result) === JSON.stringify(merge.result);

  const verification = document.getElementById("verification");
  verification.textContent = outputsMatch
    ? "✓ Verification passed: both algorithms produced identical sorted outputs."
    : "✗ Verification failed: the outputs do not match.";
  verification.classList.toggle("fail", !outputsMatch);

  const winner = document.getElementById("winner");

  if (bubble.time < merge.time) {
    winner.textContent = "Bubble Sort was faster in this three-run median benchmark.";
  } else if (merge.time < bubble.time) {
    winner.textContent = "Merge Sort was faster in this three-run median benchmark.";
  } else {
    winner.textContent = "Both algorithms recorded the same median time.";
  }

  const maxTime = Math.max(bubble.time, merge.time);
  document.getElementById("chart").innerHTML =
    displayBar("Bubble Sort", bubble.time, "bubble-bar", maxTime) +
    displayBar("Merge Sort", merge.time, "merge-bar", maxTime);

  showMessage("Comparison completed. Each time shown is the median of three runs.");
}

function generateRandom() {
  const count = 20;
  const values = Array.from(
    { length: count },
    () => Math.floor(Math.random() * 1000) + 1
  );

  numbersInput.value = values.join(", ");
  showMessage("20 random integers generated. Click Run comparison to sort them.");
}

function resetPage() {
  numbersInput.value = "64, 25, 12, 22, 11, 90, 5";

  document.getElementById("original").textContent = "64, 25, 12, 22, 11, 90, 5";
  document.getElementById("inputCount").textContent = "7 numbers";
  document.getElementById("bubbleResult").textContent = "Waiting for comparison…";
  document.getElementById("mergeResult").textContent = "Waiting for comparison…";
  document.getElementById("bubbleTime").textContent = "—";
  document.getElementById("mergeTime").textContent = "—";
  document.getElementById("winner").textContent =
    "Run the comparison to see which algorithm was faster in this test.";
  document.getElementById("chart").innerHTML =
    '<p class="empty-chart">Your timing bars will appear here.</p>';

  const verification = document.getElementById("verification");
  verification.textContent = "Verification: not performed";
  verification.classList.remove("fail");

  showMessage("Project reset to the sample input.");
}

document.getElementById("compareBtn").addEventListener("click", compareSorting);
document.getElementById("randomBtn").addEventListener("click", generateRandom);
document.getElementById("resetBtn").addEventListener("click", resetPage);
