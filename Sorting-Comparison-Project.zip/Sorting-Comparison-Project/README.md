# Sorting Comparison: Bubble Sort and Merge Sort

An interactive browser-based mini project that implements Bubble Sort and Merge Sort, sorts the same input data with both algorithms, measures execution time, and verifies that their outputs match.

## Project objectives

- Understand how Bubble Sort and Merge Sort work.
- Implement both sorting algorithms.
- Sort identical input data using separate copies.
- Measure and compare execution times.
- Verify that both algorithms produce the same ascending-order output.
- Study time and auxiliary-space complexity.

## Technologies used

- HTML — page structure
- CSS — layout and responsive design
- JavaScript — sorting algorithms, input validation and timing
- GitHub Pages — public website hosting

No database, server, external package or build step is required.

## Files

| File | Purpose |
|---|---|
| `index.html` | Website structure and content |
| `style.css` | Website design and responsive layout |
| `script.js` | Bubble Sort, Merge Sort, timing and validation |
| `README.md` | Project documentation |

## How to run locally

1. Download or clone this repository.
2. Keep all four files in the same folder.
3. Open `index.html` in a modern web browser.
4. Enter numbers separated by commas, or click **Generate random data**.
5. Click **Run comparison** to see both sorted outputs, timings and verification.

## How the comparison works

1. Read the original list of numbers.
2. Make an independent copy for each algorithm.
3. Run Bubble Sort and measure only the sorting operation.
4. Run Merge Sort and measure only the sorting operation.
5. Repeat each measurement three times and report the median.
6. Compare the sorted outputs to verify correctness.

The copy operation is outside the timed section. Browser timing uses `performance.now()`. Results can vary depending on the browser, device and system workload. For very small inputs, timings may be close to the timer's measurement resolution.

## Algorithm complexity

| Algorithm | Best time | Average time | Worst time | Auxiliary space |
|---|---|---|---|---|
| Bubble Sort (with early stop) | O(n) | O(n²) | O(n²) | O(1) |
| Merge Sort | O(n log n) | O(n log n) | O(n log n) | O(n) |

## Test cases

| Test | Input | Expected sorted output |
|---|---|---|
| TC01 | `5, 2, 4, 1` | `1, 2, 4, 5` |
| TC02 | `1, 2, 3, 4` | `1, 2, 3, 4` |
| TC03 | `9, 7, 5, 3` | `3, 5, 7, 9` |
| TC04 | `4, 2, 4, 1, 2` | `1, 2, 2, 4, 4` |
| TC05 | Empty input | Empty output |
| TC06 | `8` | `8` |

## Publish with GitHub Pages

1. Create a **public** GitHub repository.
2. Upload `index.html`, `style.css`, `script.js` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then save.
6. Wait for deployment. GitHub will show the public website URL in the Pages settings.

## Conclusion

Bubble Sort is straightforward and uses constant auxiliary space, but its average and worst-case running time is O(n²). Merge Sort uses divide and conquer and has O(n log n) time complexity, making it generally more suitable for larger lists, although it requires additional memory. Actual measured times depend on the test environment.

## References

- Cormen, T. H., Leiserson, C. E., Rivest, R. L. and Stein, C. *Introduction to Algorithms*, 4th ed., MIT Press, 2022.
- Python Software Foundation, [Time — time access and conversions](https://docs.python.org/3/library/time.html).
- GitHub Docs, [What is GitHub Pages?](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages).

---

**Mini Project:** Sorting Comparison — Bubble Sort and Merge Sort  
**Department:** Computer Science and Engineering
